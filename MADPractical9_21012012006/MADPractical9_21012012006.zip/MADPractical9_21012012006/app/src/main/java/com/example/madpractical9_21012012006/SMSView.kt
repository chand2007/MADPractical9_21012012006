package com.example.madpractical9_21012012006

class SMSView(val phoneNo:String,val msg:String) {
}